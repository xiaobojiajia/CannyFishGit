--为鱼鱼而设计的动画管理器
--auchor: xiabo.wu
--date: 2014-12-09

local FishAnimateUnit = class("FishAnimateUnit")

--鱼鱼动画模板
FishAnimateUnit.Fish_Plist_Template={"%d_normal_Big_Normal_%d.png",	
									 "%d_normal_Big_Eat_%d.png",
									 "%d_normal_Big_Turn_%d.png",
									 "%d_normal_Big_Ext_%d.png",
									 "%d_normal_Big_Ext_%d.png"} 
--皇冠动画模板									
FishAnimateUnit.Util_Plist_Template={"%d_ulti_Ulti_Eat_%d.png",
									 "%d_ulti_Ulti_Eat_%d.png",
									 "%d_ulti_Ulti_Turn_%d.png",
									 "%d_ulti_Ulti_Ext_%d.png",
									 "%d_ulti_Ulti_Ext_%d.png"}  
FishAnimateUnit.									.								
									
  
--鱼鱼动画构造器
function FishAnimateUnit:ctor(fishMetaID)
	if self:initWithMetaID(fishMetaID) then 
	   return self
	end
	return nil
end
 
--根据鱼鱼的MetaID初始化鱼鱼动画管理器
function FishAnimateUnit:initWithMetaID(fishMetaID) 
	assert(fishMetaID,"FishAnimateUnit Meta ID  Error!")
    self.nFishMetaID_	    	= fishMetaID
	self.tFishAnimateGroup_ 	= {}
	self.tUtilAnimateGroup_ 	= {}
	self.bExsitExtAnimate_  	= false  
	self.bExsitUtilAnimate_ 	= false
	self.bNeedLoadUnitAnimate_  = false 
	self.sNormalFileName_ 	    = ""
	self.sUtilFileName_  		= ""
end

--加载鱼鱼动画数据
function FishAnimateUnit:loadFishAnimates(bLoadUtilsConfig)    
	 
end

function FishAnimateUnit:innerLoadFishAnimatesByType(fishAnimateType)
   local  plistFileName = string.format(FishAnimateUnit.Fish_Plist_Template[fishAnimateType]
end



--根据动画类型获取对应的鱼鱼游动动画
function FishAnimateUnit:getFishAnimateByType(animateType) 
	
end

--根据动画类型获取对应的鱼鱼黄冠游动动画
function FishAnimateUnit:getUtilAnimateByType(animateType)  
	
end
 

--获取当前鱼鱼是否存在扩展动画
function FishAnimateUnit:bExistExtAniamte() 

end

--获取当前鱼鱼是否存在皇冠动画
function FishAnimateUnit:bExistUtilAnimate() 
	
end
 
 



return FishAnimateUnit 