 
--1.公共事件消息 
--2.公共数据类型 
--3.公共常量配置

EventType.DefaultAnchor 	  =   ccp(0.5,0.5)


--鱼鱼动画类型
EventType.UnKown_Animate_Type =   -1   --未知动画类型
EventType.Normal_Animate_Type =   0    --普通游动类型
EventType.Eat_Animate_Type    =   1    --吃食动画类型
EventType.Turn_Animate_Type   =   2    --转身动画类型
EventType.Ext_Animate_Type    =   3    --扩展动画类型







